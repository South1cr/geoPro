//#################################################
//##### Script file for multivariate Symbology ####
//#################################################


/// initialize globals

var map;
var kml;
var popup;


//######################
//##### OpenLayers #####
//######################
$(document).ready(function() {
	
	function styleMap(feature){ // sets the style for each feature in the homicide rate kml layer
		var value = feature.B.PO9195;
		var col;
		if(value < 60000){ // change saturation based on value, higher = more saturation
			col = 'rgba(210,210,255,.7)';
		}
		else if(value < 100000){
			col = 'rgba(160,160,255,.7)';
		}
		else if(value < 200000){
			col = 'rgba(90,90,255,.7)';
		}
		else if(value < 500000){
			col = 'rgba(45,45,255,.7)';
		}
		else if(value >= 500000){
			col = 'rgba(0,0,255,.7)';
		}
		var featStyle = [new ol.style.Style ({ 
          fill: new ol.style.Fill({
             color: col,
           }),
		   stroke: new ol.style.Stroke ({
			   color: 'rgb(255,255,255)',
		   })
		})];
		return featStyle;
	}
	
	
	
	
	kml = new ol.layer.Vector({ // Homicide Layer imported from kml file as vector layer
		source: new ol.source.Vector({
			url: 'homicide_Houston.kml',
			format: new ol.format.KML({
				extractStyles: false
			})
		}), 
		style: 	styleMap
		
    });	
	
    map = new ol.Map({ // OpenLayers map object
		target: 'map',
		controls: [],
		layers: [
			new ol.layer.Tile({
				source: new ol.source.OSM()
			}),
			kml
		],
		view: new ol.View({ // makes it so the map viewer starts over the area of interest, in this case houston
			center: ol.proj.transform([-95, 30.5], 'EPSG:4326', 'EPSG:3857'),
			projection: ol.proj.get('EPSG:3857'),
			zoom: 7
		})
	});
	
	
	popup = new ol.Overlay.Popup(); // popup object
	map.addOverlay(popup);
	
	
	 var select = new ol.interaction.Select({ // create click/select event for homicide rate layer
      layers: [kml]
    });
	
	map.addInteraction(select); // activates the homicide rate layer event
	 
	select.getFeatures().on("add", function (evt) {  // code to execute when Homicide rate feature is selected
		feature = evt.target.a[0];
		var loc = feature.getGeometry().getCoordinates();
		//var extent = feature.a[0].getGeometry().getExtent();
		loc = loc[0][0];
		var center = geoPro.getCentroid(feature);
		x = center;
		var center = [center.getGeometry().getCoordinates()[0],center.getGeometry().getCoordinates()[1]];
		console.log(center);
		var hRate = feature.B.HR9195;
		hRate = (Math.round(hRate * 10) / 10);
		popup.show(center, "<p>Homicide Rate: <span>" + hRate + "</span><br>*per 100,000 persons</p>"); // show popup with corresponding data
	});
	
	
	map.on('click', function(evt){ // makes it so clicking off of Houston layer area or double clicking feature closes popup
		popup.hide();
	});


});



//##############################
//#### jQuery functionality #### 
//##############################
$(document).ready(function(){

	$('#run').click(function(){ // Button event handler for running the gradSymbol method from geoPro
		var size;
		var color;
		if($('#size').val() == ''){
			size = 100;
		} else {
			size = $('#size').val();
		}
		if($('#color').val() == ''){
			color = 'red';
		} else {
			color = $('#color').val();
		}
		if($('#field').val() == ''){
			field = 'HR9195';
		} else {
			field = $('#field').val();
		}
		if(typeof(propSymbol) != 'undefined'){  
			map.removeLayer(propSymbol);
		}
		propSymbol = geoPro.proportionalSymbol(kml,'EPSG:3857', field, size, color);
		map.addLayer(propSymbol);
		
	});


	$('#grey').click(function(){ // event handler that removes the graduated symbols if desired.
		if(typeof(gradSymbol) != 'undefined'){
			map.removeLayer(gradSymbol);
		}
	});
	

});


	

	
