//#################################################
//##### Script file for multivariate Symbology ####
//#################################################


/// initialize globals

var map;
var firstFeature;
var secondFeature;


//######################
//##### OpenLayers #####
//######################
$(document).ready(function() {
	
	
	source = new ol.source.Vector({wrapX: false});
	
	vector = new ol.layer.Vector({
	  source: source,
	  style: new ol.style.Style({
		fill: new ol.style.Fill({
		  color: 'rgba(255, 255, 255, 0.2)'
		}),
		stroke: new ol.style.Stroke({
		  color: '#ffcc33',
		  width: 2
		}),
		image: new ol.style.Circle({
		  radius: 7,
		  fill: new ol.style.Fill({
			color: '#ffcc33'
		  })
		})
	  })
	});
	
	
	var ring1 = [
		[-95.298, 29.604], [-95.298, 29.604],
		[-95.298, 29.604], [-95.298, 29.604], [-95.298, 29.604]
	]
	
	
	var feature1 = new ol.Feature({
            geometry: new ol.geom.Polygon([ring1])
        });
	feature1.getGeometry().transform('EPSG:4326', 'EPSG:3857');
	
	outputSource = new ol.source.Vector({
		features: [feature1]
	});
	outputLayer = new ol.layer.Vector({
        source: outputSource,
		style: new ol.style.Style({
		fill: new ol.style.Fill({
		  color: 'rgba(255, 0, 0, .5)'
		}),
		stroke: new ol.style.Stroke({
		  color: 'rgb(0,0,0)',
		  width: 2
		}),
		image: new ol.style.Circle({
		  radius: 7,
		  fill: new ol.style.Fill({
			color: '#ffcc33'
		  })
		})
	  })
    });
	
	/*
	outputPointSource = new ol.source.Vector({
	});
	outputPointLayer = new ol.layer.Vector({
        source: outputSource,
    });*/
	
	
	
    map = new ol.Map({ // OpenLayers map object
		target: 'map',
		controls: [],
		layers: [
			new ol.layer.Tile({
				source: new ol.source.OSM()
			}),
			vector, 
			outputLayer,
			//outputPointLayer
		],
		view: new ol.View({ // makes it so the map viewer starts over the area of interest, in this case houston
			center: ol.proj.transform([-95, 30.5], 'EPSG:4326', 'EPSG:3857'),
			projection: ol.proj.get('EPSG:3857'),
			zoom: 7
		})
	});
	
	var typeSelect = document.getElementById('type');
	var toolTypeSelect = document.getElementById('toolType');
	var select1 = new ol.interaction.Select({
		layers: [vector],
	});
	var select2 = new ol.interaction.Select({
	  layers: [vector],
	});

	var draw; // global so we can remove it later
	function addInteraction() {
		removeInteractions();
	  var value = typeSelect.value;
	  if (value !== 'None') {
		var geometryFunction, maxPoints;
		if (value === 'Square') {
		  value = 'Circle';
		  geometryFunction = ol.interaction.Draw.createRegularPolygon(4);
		} else if (value === 'Box') {
		  value = 'LineString';
		  maxPoints = 2;
		  geometryFunction = function(coordinates, geometry) {
			if (!geometry) {
			  geometry = new ol.geom.Polygon(null);
			}
			var start = coordinates[0];
			var end = coordinates[1];
			geometry.setCoordinates([
			  [start, [start[0], end[1]], end, [end[0], start[1]], start]
			]);
			return geometry;
		  };
		}
		draw = new ol.interaction.Draw({
		  source: source,
		  type: /** @type {ol.geom.GeometryType} */ (value),
		  geometryFunction: geometryFunction,
		  maxPoints: maxPoints
		});
		map.addInteraction(draw);
	  }
	}
	
	function changeToolLayout(tool) {
		console.log(tool);
		if(tool == 'getCentroid'){
			var htmlString = '<table><tbody><tr><th><button class="btn btn-primary" onClick="selectFeature1()">Select Feature</button></th></tr></tbody></table>';
			$('#multiButton').html(htmlString);
		}
		if(tool == 'erase'){
			var htmlString = '<table><tbody><tr><th><button class="btn btn-primary" onClick="selectFeature1()">Select First Feature</button></th></tr><tr><th><button class="btn btn-danger" onClick="selectFeature2()">Select Second Feature</button></th></tr><tr><th><button class="btn btn-success" onClick="runErase()">Run Erase</button></th></tr></tbody></table>';
			$('#multiButton').html(htmlString);
		}
		if(tool == 'clip'){
			
		}
		if(tool == 'buffer'){
			var htmlString = '<table><tbody><tr><th><button class="btn btn-primary" onClick="selectFeature1()">Select Feature</button></th></tr><tr><th><label for="distance">Distance (Meters):</label><input type="text" class="form-control" id="distance"></th></tr><tr><th><button class="btn btn-success" onClick="runBuffer()">Run Buffer</button></th></tr></tbody></table>';
			$('#multiButton').html(htmlString);
		}
	}
	
	removeInteractions = function(){
		map.removeInteraction(draw);
		map.removeInteraction(select1);
		map.removeInteraction(select2);
	}
	
	selectFeature1 = function(){
		removeInteractions();
		
		map.addInteraction(select1);
		var selectedFeatures = select1.getFeatures();
		selectedFeatures.on('add', function(event) {
		  var feature = event.element;
			firstFeature = feature;

			if(toolTypeSelect.value == 'getCentroid'){
				var centroid = geoPro.getCentroid(firstFeature);
				outputSource.addFeature(centroid);
				//removeInteractions();
			}
		 
		});
	}
	
	selectFeature2 = function(){
		removeInteractions();
		
		map.addInteraction(select2);
		var selectedFeatures = select2.getFeatures();
		selectedFeatures.on('add', function(event) {
		  var feature = event.element;
			secondFeature = feature;

		  // put the url of the feature into the photo-info div
		 
		});
	}
	
	runErase = function(){
		removeInteractions();
		var erasedFeature = geoPro.erase(firstFeature,secondFeature);
		if(erasedFeature){
			outputSource.addFeature(erasedFeature);
		} else{
			alert('please select two polygon features');
		}
		var featGeom = erasedFeature.getGeometry();
		var featCoords = featGeom.getCoordinates()[0];
		var counter = 0;		
		/*seismicBullshit = setInterval(function(){
			var x1 = featCoords[counter][0];
			var y1 = featCoords[counter][1];
			outputSource.addFeature(new ol.Feature({geometry: new ol.geom.Point([x1,y1])}));
			counter +=1;
			if(counter == featCoords.length){
				clearInterval(seismicBullshit);
			}
		}, 1500);*/
	}
	
	runBuffer = function(){
		removeInteractions();
		var distance = $('#distance').val();
		var bufferedFeature = geoPro.buffer(firstFeature,distance,'METERS');
		if(bufferedFeature){
			outputSource.addFeature(bufferedFeature);
		} else{
			console.log('no feature returned');
			alert('please select a feature');
		}
		x = bufferedFeature;
		var featGeom = bufferedFeature.getGeometry();
		var featCoords = featGeom.getCoordinates()[0];
		var counter = 0;		
		/*seismicBullshit = setInterval(function(){
			var x1 = featCoords[counter][0];
			var y1 = featCoords[counter][1];
			outputSource.addFeature(new ol.Feature({geometry: new ol.geom.Point([x1,y1])}));
			counter +=1;
			if(counter == featCoords.length){
				clearInterval(seismicBullshit);
			}
		}, 1500);*/
	}

	/**
	 * Let user change the geometry type.
	 * @param {Event} e Change event.
	 */
	typeSelect.onchange = function(e) {
	  map.removeInteraction(draw);
	  addInteraction();
	};

	addInteraction();
	
	toolTypeSelect.onchange = function(e) {
	  var tool = toolTypeSelect.value;
	  changeToolLayout(tool);
	};


});





	

	
