//#################################################
//##### Script file for buffer ############### ####
//#################################################


/// initialize globals

var map;
var vectorLayer;
var tempLayer;


//######################
//##### OpenLayers #####
//######################
$(document).ready(function() {
	

	var path = [
		[-95.3698, 29.7604], [-97.3698, 29.7604],
		[-97.3698, 31.7604], [-95.3698, 31.7604]
	];
	

	
	var feature1 = new ol.Feature({
            geometry: new ol.geom.LineString(path)
        });
		

	
	feature1.getGeometry().transform('EPSG:4326', 'EPSG:3857');
	vectorSource= new ol.source.Vector({
        features: [feature1]
    });
	vectorLayer = new ol.layer.Vector({
        source: vectorSource
    });
	
	
    map = new ol.Map({ // OpenLayers map object
		target: 'map',
		controls: [],
		layers: [
			new ol.layer.Tile({
				source: new ol.source.OSM()
			}),
			vectorLayer
		],
		view: new ol.View({ // makes it so the map viewer starts over the area of interest, in this case houston
			center: ol.proj.transform([-95, 30.5], 'EPSG:4326', 'EPSG:3857'),
			projection: ol.proj.get('EPSG:3857'),
			zoom: 7
		})
	});
	
	
	



});



//##############################
//#### jQuery functionality #### 
//##############################
$(document).ready(function(){

	$('#run').click(function(){ // Button event handler for running the gradSymbol method from geoPro
		var feat1 = vectorLayer.getSource().getFeatures()[0];
		var buffFeature = geoPro.buffer(feat1, 10000, 'feet');
		console.log(buffFeature);
		//var positive = buffFeature[0];
		//var negative = buffFeature[1];
		vectorSource.addFeature(buffFeature);

		/*negative.forEach(function(i){
			vectorSource.addFeature(new ol.Feature({geometry: new ol.geom.Point(i)}));
		});
		negative.forEach(function(i){
			vectorSource.addFeature(i);
		});*/
		

			


		
	});


	$('#grey').click(function(){ // event handler that removes the graduated symbols if desired.
		map.removeLayer(tempLayer);
	});

});

