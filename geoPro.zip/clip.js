//#################################################
//##### Script file for clip ################# ####
//#################################################


/// initialize globals

var map;
var vectorLayer;
var tempLayer;


//######################
//##### OpenLayers #####
//######################
$(document).ready(function() {
	

	var ring1 = [
		[-95.3698, 29.7604], [-97.3698, 29.7604],
		[-97.3698, 31.7604], [-95.3698, 31.7604], [-95.3698, 29.7604]
	]
	
	/*var ring2 = [
		[-94.3698, 28.7604], [-96.3698, 28.7604], [-96.3698, 29.25], [-97.5, 29.25], [-97.5, 30.25], [-96.6, 30.25], [-96.3698, 29.6],
		[-96.3698, 30.304], [-96.198, 30.7604], [-94.798, 30.7604], [-94.798, 31], [-96.198, 31], [-96.198, 31.5], [-94.3698, 31.5], [-94.3698, 28.7604]
	]*/
	
	
	var ring2 = [
		[-95.298, 29.604], [-97.598, 29.604],
		[-97.598, 30.7604], [-95.298, 30.7604], [-95.298, 29.604]
	]
	
	
	var feature1 = new ol.Feature({
            geometry: new ol.geom.Polygon([ring1])
        });
		
	var feature2 = new ol.Feature({
            geometry: new ol.geom.Polygon([ring2])
        });
	
	feature1.getGeometry().transform('EPSG:4326', 'EPSG:3857');
	feature2.getGeometry().transform('EPSG:4326', 'EPSG:3857');
	var vectorSource= new ol.source.Vector({
        features: [feature1,feature2]
    });
	vectorLayer = new ol.layer.Vector({
        source: vectorSource
    });
	
	
    map = new ol.Map({ // OpenLayers map object
		target: 'map',
		controls: [],
		layers: [
			new ol.layer.Tile({
				source: new ol.source.OSM()
			}),
			vectorLayer
		],
		view: new ol.View({ // makes it so the map viewer starts over the area of interest, in this case houston
			center: ol.proj.transform([-95, 30.5], 'EPSG:4326', 'EPSG:3857'),
			projection: ol.proj.get('EPSG:3857'),
			zoom: 7
		})
	});
	
	
	



});



//##############################
//#### jQuery functionality #### 
//##############################
$(document).ready(function(){

	$('#run').click(function(){ // Button event handler for running the gradSymbol method from geoPro
		map.removeLayer(tempLayer);
		var feat1 = vectorLayer.getSource().getFeatures()[0];
		var feat2 = vectorLayer.getSource().getFeatures()[1];
		clip = geoPro.clip(feat1,feat2);
		clipSource = new ol.source.Vector({});
		clipSource.addFeature(clip);
		var tempStyle = new ol.style.Style ({
				fill: new ol.style.Fill({
				color: 'red',
				})
		});
		var testStyle = new ol.style.Style ({
				fill: new ol.style.Fill({
				color: 'blue',
				})
		});
		/*clip.forEach(function(i){
			var feature = new ol.Feature({ geometry: new ol.geom.Point([i])});
			clipSource.addFeature(feature);
			
		});*/
		tempLayer = new ol.layer.Vector({ // create temporary layer from constructor
			source: clipSource,
			style: tempStyle 
		});
		map.addLayer(tempLayer);
		
		var featGeom = clip.getGeometry();
		var featCoords = featGeom.getCoordinates()[0];
		var counter = 0;		
		seismicBullshit = setInterval(function(){
			testSource = new ol.source.Vector({});
			testLayer = new ol.layer.Vector({ // create temporary layer from constructor
				source: testSource
			});
		
			var x1 = featCoords[counter][0];
			var y1 = featCoords[counter][1];
			testSource.addFeature(new ol.Feature({geometry: new ol.geom.Point([x1,y1])}));
			map.addLayer(testLayer);
			counter +=1;
			if(counter == featCoords.length){
				clearInterval(seismicBullshit);
			}
		}, 1500);
		
		
		

		
	});
	
	function testPoints(counter){
		
		
	}


	$('#grey').click(function(){ // event handler that removes the graduated symbols if desired.
		map.removeLayer(tempLayer);
	});

});


	

	
